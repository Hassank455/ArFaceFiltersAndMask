package com.example.ar_face_filters_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
